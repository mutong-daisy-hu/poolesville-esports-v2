/* ============================================================
   POOLESVILLE FALCON ESPORTS — Shared JS
   ============================================================ */

// ── Admin state (simple in-memory prototype) ──
const ADMIN_USER = 'poolesville';
const ADMIN_PASS = 'esports';
const LOCKOUT_MS = 5 * 60 * 1000;

let adminState = {
  loggedIn: false,
  attempts: 0,
  lockedUntil: null,
  lockoutTimer: null
};

// ── Hamburger menu ──
function initNav() {
  const hamburger = document.getElementById('hamburger');
  const mobileMenu = document.getElementById('mobile-menu');
  if (hamburger && mobileMenu) {
    hamburger.addEventListener('click', () => {
      mobileMenu.classList.toggle('open');
    });
  }

  // Mark active nav link
  const page = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a, .dropdown-menu a').forEach(a => {
    const href = a.getAttribute('href');
    if (href && href.includes(page)) a.classList.add('active');
  });
}

// ── Admin bar / login ──
function initAdminBar() {
  const bar = document.getElementById('admin-bar');
  if (!bar) return;
  document.body.classList.add('has-admin-bar');

  const link = document.getElementById('admin-link');
  if (link) {
    link.addEventListener('click', () => {
      if (adminState.loggedIn) return;
      if (adminState.lockedUntil && Date.now() < adminState.lockedUntil) {
        showLockout(); return;
      }
      document.getElementById('login-overlay').classList.add('show');
      document.getElementById('login-user').value = '';
      document.getElementById('login-pass').value = '';
      document.getElementById('login-error').style.display = 'none';
      document.getElementById('login-submit').disabled = false;
    });
  }
}

function attemptLogin() {
  if (adminState.lockedUntil && Date.now() < adminState.lockedUntil) {
    showLockout(); return;
  }
  const user = document.getElementById('login-user').value.trim();
  const pass = document.getElementById('login-pass').value;
  const errEl = document.getElementById('login-error');

  if (user === ADMIN_USER && pass === ADMIN_PASS) {
    adminState.loggedIn = true;
    adminState.attempts = 0;
    document.getElementById('login-overlay').classList.remove('show');
    setAdminLoggedIn();
  } else {
    adminState.attempts++;
    errEl.style.display = 'block';
    if (adminState.attempts >= 3) {
      adminState.lockedUntil = Date.now() + LOCKOUT_MS;
      document.getElementById('login-submit').disabled = true;
      document.getElementById('login-overlay').classList.remove('show');
      showLockout();
      startLockoutTimer();
    }
  }
}

function setAdminLoggedIn() {
  const link = document.getElementById('admin-link');
  if (link) {
    link.textContent = 'Logged in as administrator';
    link.classList.add('logged-in');
  }
  document.querySelectorAll('.admin-only').forEach(el => el.style.display = '');
}

function showLockout() {
  document.getElementById('lockout-overlay').classList.add('show');
  updateLockoutTimer();
}

function startLockoutTimer() {
  if (adminState.lockoutTimer) clearInterval(adminState.lockoutTimer);
  adminState.lockoutTimer = setInterval(() => {
    if (Date.now() >= adminState.lockedUntil) {
      clearInterval(adminState.lockoutTimer);
      adminState.attempts = 0;
      adminState.lockedUntil = null;
      document.getElementById('lockout-overlay').classList.remove('show');
      document.getElementById('login-submit').disabled = false;
      document.getElementById('login-error').style.display = 'none';
    } else {
      updateLockoutTimer();
    }
  }, 1000);
}

function updateLockoutTimer() {
  const el = document.getElementById('lockout-timer');
  if (!el || !adminState.lockedUntil) return;
  const remaining = Math.max(0, adminState.lockedUntil - Date.now());
  const m = Math.floor(remaining / 60000);
  const s = Math.floor((remaining % 60000) / 1000);
  el.textContent = `Try again in ${m}:${String(s).padStart(2, '0')}`;
}

// ── FAQ / toggle ──
function initToggles() {
  document.querySelectorAll('.toggle-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const panel = btn.closest('.match-toggle').nextElementSibling;
      const isOpen = panel.classList.contains('open');
      panel.classList.toggle('open', !isOpen);
      btn.textContent = isOpen ? 'Show Highlights ▼' : 'Hide Highlights ▲';
      btn.setAttribute('aria-expanded', String(!isOpen));
    });
  });

  document.querySelectorAll('.faq-q').forEach(q => {
    q.addEventListener('click', () => q.closest('.faq-item').classList.toggle('open'));
  });
}

// ── Clip modal (highlights page) ──
let pendingClip = null;

function extractYTId(url) {
  const m = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/);
  return m ? m[1] : null;
}

function initClipModal() {
  const urlInput = document.getElementById('clip-url');
  if (!urlInput) return;

  let debounce = null;
  urlInput.addEventListener('input', function () {
    clearTimeout(debounce);
    const val = this.value.trim();
    const status = document.getElementById('clip-url-status');
    const addBtn = document.getElementById('modal-add-btn');
    const previewEmpty = document.getElementById('clip-preview-empty');
    pendingClip = null;
    addBtn.disabled = true;
    if (!val) { status.textContent = ''; previewEmpty.style.display = 'flex'; return; }
    const vid = extractYTId(val);
    if (!vid) { status.textContent = 'Not a valid YouTube URL.'; status.className = 'clip-url-status err'; previewEmpty.style.display = 'flex'; return; }
    debounce = setTimeout(() => {
      let iframe = document.querySelector('#clip-preview-box iframe');
      if (!iframe) {
        iframe = document.createElement('iframe');
        iframe.allowFullscreen = true;
        iframe.allow = 'accelerometer;autoplay;clipboard-write;encrypted-media;gyroscope;picture-in-picture';
        document.getElementById('clip-preview-box').insertBefore(iframe, document.getElementById('clip-preview-empty'));
      }
      iframe.src = `https://www.youtube.com/embed/${vid}`;
      previewEmpty.style.display = 'none';
      status.textContent = '✓ Valid YouTube URL'; status.className = 'clip-url-status ok';
      pendingClip = { vid };
      addBtn.disabled = false;
      updateClipPreviewMeta();
    }, 500);
  });

  ['clip-game', 'clip-player'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('input', updateClipPreviewMeta);
  });
}

function updateClipPreviewMeta() {
  const g = (document.getElementById('clip-game') || {}).value || '';
  const p = (document.getElementById('clip-player') || {}).value || '';
  const el = document.getElementById('clip-preview-title');
  if (el) el.textContent = `Game: ${g || '—'} | Player: ${p || '—'}`;
  document.getElementById('clip-preview-info').style.display = 'block';
  if (pendingClip) { pendingClip.game = g; pendingClip.player = p; }
}

function openClipModal() {
  ['clip-url', 'clip-game', 'clip-player'].forEach(id => {
    const el = document.getElementById(id); if (el) el.value = '';
  });
  document.getElementById('clip-url-status').textContent = '';
  document.getElementById('clip-preview-empty').style.display = 'flex';
  document.getElementById('clip-preview-info').style.display = 'none';
  document.getElementById('modal-add-btn').disabled = true;
  const iframe = document.querySelector('#clip-preview-box iframe');
  if (iframe) iframe.remove();
  pendingClip = null;
  document.getElementById('clip-modal-overlay').classList.add('show');
}

function closeClipModal() {
  document.getElementById('clip-modal-overlay').classList.remove('show');
}

function addClip() {
  if (!pendingClip) return;
  const g = pendingClip.game || '—';
  const p = pendingClip.player || '—';
  const grid = document.getElementById('main-video-grid');
  if (!grid) return;
  const card = document.createElement('div');
  card.className = 'video-card';
  card.style.position = 'relative';
  card.innerHTML = `
    <iframe src="https://www.youtube.com/embed/${pendingClip.vid}" loading="lazy"
      title="Added highlight clip" allowfullscreen
      allow="accelerometer;autoplay;clipboard-write;encrypted-media;gyroscope;picture-in-picture"
      style="width:100%;aspect-ratio:16/9;border:none;border-radius:4px;display:block;"></iframe>
    <div style="padding:8px 10px;font-size:0.82rem;color:var(--muted);">Game: ${g} | Player: ${p}</div>
    <button class="trash-btn" onclick="removeClip(this)" title="Remove clip">🗑</button>`;
  grid.insertBefore(card, grid.firstChild);
  closeClipModal();
}

function removeClip(btn) {
  if (confirm('Remove this clip?')) btn.closest('.video-card').remove();
}

// ── Schedule editing ──
let editingSchedule = false;

function toggleEditSchedule() {
  editingSchedule = !editingSchedule;
  const table = document.getElementById('spring-schedule');
  const btn = document.getElementById('edit-schedule-btn');
  if (!table || !btn) return;

  if (editingSchedule) {
    btn.textContent = '💾 Save Schedule';
    btn.classList.add('btn-primary');
    btn.classList.remove('btn-outline');
    table.querySelectorAll('td').forEach(td => {
      const orig = td.innerHTML;
      const inp = document.createElement('input');
      inp.value = td.innerText.trim();
      inp.style.cssText = 'width:100%;background:transparent;border:none;color:var(--text);font-family:inherit;font-size:inherit;padding:0;outline:none;';
      inp.addEventListener('focus', e => e.target.style.background = '#222');
      inp.addEventListener('blur', e => e.target.style.background = 'transparent');
      td.dataset.orig = orig;
      td.innerHTML = '';
      td.appendChild(inp);
    });
  } else {
    btn.textContent = '✏ Edit Schedule';
    btn.classList.remove('btn-primary');
    btn.classList.add('btn-outline');
    table.querySelectorAll('td').forEach(td => {
      const inp = td.querySelector('input');
      if (inp) td.textContent = inp.value;
    });
  }
}

// ── Init on DOM ready ──
document.addEventListener('DOMContentLoaded', () => {
  initNav();
  initAdminBar();
  initToggles();
  initClipModal();

  // Enter key on login
  const lp = document.getElementById('login-pass');
  if (lp) lp.addEventListener('keydown', e => { if (e.key === 'Enter') attemptLogin(); });

  // Hide admin-only elements until logged in
  document.querySelectorAll('.admin-only').forEach(el => el.style.display = 'none');
});
